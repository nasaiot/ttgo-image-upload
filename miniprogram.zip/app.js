import { promisifyAll, promisify } from 'miniprogram-api-promise';
const wxp = {}
// promisify all wx's api
promisifyAll(wx, wxp)
App({
  wx:wxp,
  onLaunch: function () {
  }
})
