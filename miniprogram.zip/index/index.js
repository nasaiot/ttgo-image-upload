const app = getApp()
Page({
  data: {
    host: '192.168.4.1'
  },
  async getfiles() {
    const res = await app.wx.chooseMessageFile({
      type: 'image',
    })
    if (res.errMsg == 'chooseMessageFile:ok') {
      return res.tempFiles
    } else {
      return []
    }
  },
  async upload(path) {
    const _self = this
    _self.setData({
      img: path
    })
    wx.showLoading({
      title: "传输中。。。"
    })
    try {
      const res = await app.wx.uploadFile({
        filePath: path,
        name: 'fileToUpload',
        url: `http://${_self.data.host}/upload`,
        header: {
          'Content-Type': 'multipart/form-data; boundary='
        },
      })
      console.log(res)
      wx.hideLoading()
      if (res.statusCode != 200) {
        wx.showToast({
          title: '传输失败',
          icon: 'none',
          duration: 2000
        })
      }
      return res.statusCode
    } catch (error) {
      wx.hideLoading()
      wx.showToast({
        title: error.errMsg,
        icon: 'none',
        duration: 2000
      })
      return 500
    }
  },
  async setimg() {
    wx.showLoading({
      title: "设置中。。。"
    })
    const _self = this
    try {
      const res = await app.wx.request({
        url: `http://${_self.data.host}/logo.bmp`
      })
      wx.hideLoading()
      console.log('set img:', res)
      if (res.statusCode == 200) {
        wx.showToast({
          title: '设置成功',
          icon: 'success',
          duration: 2000
        })
      } else {
        wx.showToast({
          title: '设置失败',
          icon: 'none',
          duration: 2000
        })
      }
      return res.statusCode
    } catch (error) {
      wx.hideLoading()
      wx.showToast({
        title: error.errMsg,
        icon: 'none',
        duration: 2000
      })
      return 500
    }
  },
  async looping(files) {
    const _self = this
    if (files.length > 0) {
      const file = files[0]
      console.log(file)
      files.splice(0, 1)
      const status = await _self.upload(file.path)
      if (status == 200) {
        const code = await _self.setimg()
        if (code == 200) {
          setTimeout(() => {
            _self.looping(files)
          }, 20);
        }
      }
    }
  },
  async up() {
    const _self = this
    const files = await _self.getfiles()
    console.log(files)
    if (files.length == 0) {
      //none
    }
    if (files.length == 1) {
      //one
      const path = files[0].path
      const code = await _self.upload(path)
      if (code == 200) {
        await _self.setimg()
      }
    }
    if (files.length > 1) {
      _self.looping(files)
    }
  },
  input: function (event) {
    this.setData({
      host: event.detail.value
    })
  },
  onLoad: function () {},
})